import { Injectable } from '@nestjs/common';
import { PropertyRepository } from './property.repository.service';
import { CreatePropertyDto } from './dto/create-property.dto';

@Injectable()
export class PropertyService {
  constructor(private readonly repo: PropertyRepository) {}

  create(dto: CreatePropertyDto) {
    return this.repo.create(dto);
  }

  findAll() {
    return this.repo.findAll();
  }

  findOne(id: number) {
    return this.repo.findById(id);
  }
}
