import { Injectable } from '@nestjs/common';
import { DatabaseService } from 'src/database/database/database.service';
import { CreatePropertyDto } from './dto/create-property.dto';

@Injectable()
export class PropertyRepository {
  constructor(private readonly db: DatabaseService) {}

  async create(data: CreatePropertyDto) {
    const query = `
      INSERT INTO properties (title, description, price, location)
      VALUES ($1, $2, $3, $4)
      RETURNING *;
    `;

    const values = [
      data.title,
      data.description,
      data.price,
      data.location,
    ];

    const result = await this.db.query(query, values);
    return result.rows[0];
  }

  async findAll() {
    const result = await this.db.query(
      `SELECT * FROM properties ORDER BY created_at DESC`
    );
    return result.rows;
  }

  async findById(id: number) {
    const result = await this.db.query(
      `SELECT * FROM properties WHERE id = $1`,
      [id],
    );
    return result.rows[0];
  }
}
